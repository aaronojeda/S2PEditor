#pragma once
#include "PlayStatePower.h"
class PowEpilogueState :
	public PlayStatePower
{
public:
	PowEpilogueState();
	~PowEpilogueState();
	virtual void update();
	virtual void render();
protected:
	virtual void drawImages();
	bool m_bFadeout{ false };
	void fadeout();
};

