#include "PowNormalEndState.h"
#include "TextureManager.h"
#include "Game.h"
#include "EndState.h"
#include "PlayerPower.h"
#include "EndState.h"

PowNormalEndState::PowNormalEndState()
{
	loadLevel("levels/normalEnding.xml");
	m_player = m_pLevel->getPlayer();
	m_alphaEnding = 255;
	SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
	loadText();
	m_initialTime = SDL_GetTicks();
}


PowNormalEndState::~PowNormalEndState()
{
}

void PowNormalEndState::update()
{
	if (m_bFadeInFinished)
	{
		// Se termina el fundido y el robot 2 se va
		dynamic_cast<PlayerPower*>(m_player)->goRight();
	}
}

void PowNormalEndState::render()
{
	drawImages();
	// Draw level objects and terrain
	if (m_pLevel != 0)
	{
		m_pLevel->render();
	}
	if (!m_bFadeInFinished)	fadeIn();
	if (m_player->getPosition().x() > TheGame::Instance().getWindowWidth() - 40)
	{
		fadeOut();
	}
}


void PowNormalEndState::drawImages()
{
	TheTextureManager::Instance().draw("machineOnEmpty", 209, 326, TheGame::Instance().getRenderer());
	TheTextureManager::Instance().draw("robotOff", 167, 372, TheGame::Instance().getRenderer());
	// robots health
	TheTextureManager::Instance().draw("batteryEmpty", 539, 10, TheGame::Instance().getRenderer(), SDL_FLIP_HORIZONTAL);
	TheTextureManager::Instance().draw("batteryEmpty", 10, 10, TheGame::Instance().getRenderer());
	int rectWidth = 42;
	int rectHeight = 18;
	int fillWidth = rectWidth * 20 / 100;
	SDL_SetRenderDrawColor(TheGame::Instance().getRenderer(), 232, 15, 56, SDL_ALPHA_OPAQUE);
	SDL_Rect fillRect = { 590 - fillWidth - 3, 13, fillWidth, rectHeight };
	SDL_RenderFillRect(TheGame::Instance().getRenderer(), &fillRect);
}

void PowNormalEndState::fadeIn()
{
	if (m_alphaEnding > 0)
	{
		// fade out to black
		Uint32 fadeTime = 1000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding--;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		m_bFadeInFinished = true;
		m_alphaEnding = 0;
	}
}

void PowNormalEndState::fadeOut()
{
	if (m_alphaEnding < 255)
	{
		// fade out to black
		Uint32 fadeTime = 1000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding++;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
		TheGame::Instance().getStateMachine()->changeState(new EndState());
		TheGame::Instance().getStateMachine()->dequeState();
	}
}
