#include "PlayStatePower.h"
#include "Game.h"
#include "GameOverState.h"
#include "SoundManager.h"
#include "EndState.h"
#include "InputHandler.h"
#include "PauseState.h"
#include "PlayState.h"
#include "TextureManager.h"
#include "GoodEndingState.h"
#include "PowEpilogueState.h"

using namespace std;

PlayStatePower::PlayStatePower()
{

}

PlayStatePower::PlayStatePower(int levelFile) 
{
	TheGame::Instance().setCurrentLevel(levelFile);
	m_levelFile = TheGame::Instance().getLevelFiles()[levelFile].second;
	// load current level
	loadLevel(m_levelFile);
	// Play background music
	TheSoundManager::Instance().playMusic(m_pLevel->getMusic(), -1);
	loadText();
}

PlayStatePower::PlayStatePower(std::string levelFile) : PlayState(levelFile)
{
	loadText();
}

PlayStatePower::~PlayStatePower()
{
}

void PlayStatePower::update()
{
	if (TheGame::Instance().resurrected())
	{
		// Reload level and reset player resurrected flag
		loadLevel(m_levelFile);
		TheGame::Instance().setResurrected(false);
		// Reset keys to zero
		TheGame::Instance().clearKeys();
	}
	else if (TheGame::Instance().levelCompleted())
	{
		// Check if last level
		if (TheGame::Instance().getLevelFiles()[TheGame::Instance().getCurrentLevel()].first != "finalLevel")
		{
			// Put level completed and checkPoint flags as false
			TheGame::Instance().setLevelCompleted(false);
			TheGame::Instance().setCheckPoint(false);
			// Still levels remaining
			int newLevel = TheGame::Instance().getCurrentLevel() + 1;
			TheGame::Instance().setCurrentLevel(newLevel);
			// Reset player health to initial value unless he has more
			if (TheGame::Instance().getHealth() < TheGame::Instance().getInitHealth())
			{
				TheGame::Instance().clearHealth();
			}
			m_levelFile = TheGame::Instance().getLevelFiles()[newLevel].second;
			loadLevel(newLevel);
			// Play new level's background music
			TheSoundManager::Instance().playMusic(m_pLevel->getMusic(), -1);
		}
		else
		{
			//go to epilogue
			TheGame::Instance().getStateMachine()->changeState(new PowEpilogueState());
		}
	}
	else
	{
		// Handle input and update level
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_ESCAPE))
		{
			TheGame::Instance().quit();
		}
		if (!TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN))
		{
			m_bPausePressed = false;
		}
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN) && !m_bPausePressed)
		{
			m_bPausePressed = true;
			TheGame::Instance().getStateMachine()->pushState(new PauseState());
		}
		else
		{
			m_pLevel->update();
		}
	}
}


void PlayStatePower::render()
{
	drawImages();
	drawPower();
	drawText();
	// Draw level objects and terrain
	if (m_pLevel != 0)
	{
		m_pLevel->render();
	}
}

void PlayStatePower::drawText()
{
	auto levelIndex = TheGame::Instance().getCurrentLevel();
	string levelName = TheGame::Instance().getLevelFiles()[levelIndex].first;
	if (levelName == "prologue")
	{
		TheTextureManager::Instance().draw("prologue1", 10, 75, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("prologue2", 10, 115, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("prologue3", 10, 155, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("prologue35", 10, 195, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("prologue4", 10, 235, TheGame::Instance().getRenderer());
	}
	else if (levelName == "epilogue")
	{
		TheTextureManager::Instance().draw("epilogue1", 10, 75, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("epilogue2", 10, 115, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("epilogue3", 10, 155, TheGame::Instance().getRenderer());
		TheTextureManager::Instance().draw("epilogue4", 10, 195, TheGame::Instance().getRenderer());
	}
}

void PlayStatePower::drawPower()
{
	// Dibujar el contorno de la pila
	TheTextureManager::Instance().draw("batteryEmpty", 10, 10, TheGame::Instance().getRenderer());
	if (m_pLevel->getPlayer() != nullptr && !m_pLevel->getPlayer()->dying())
	{
		// Calcular que parte de la pila llena dibujar
		int rectWidth = 42;
		int rectHeight = 18;
		int rectX = 13;
		int rectY = 13;
		auto rHealth = TheGame::Instance().getHealth();
		int powerLeft = rHealth * 100 / TheGame::Instance().getMaxHealth();
		int fillWidth = rectWidth * powerLeft / 100;
		SDL_Rect fillRect = { rectX, rectY, fillWidth, rectHeight };
		// Cambiar el color seg�n la vida restante
		if (rHealth < 75)
		{
			if (rHealth < 50)
			{
				// red
				SDL_SetRenderDrawColor(TheGame::Instance().getRenderer(), 232, 15, 56, SDL_ALPHA_OPAQUE);	
			}
			else
			{
				// yellow / orange
				SDL_SetRenderDrawColor(TheGame::Instance().getRenderer(), 232, 209, 15, SDL_ALPHA_OPAQUE);
			}
		}
		else
		{
			// green
			SDL_SetRenderDrawColor(TheGame::Instance().getRenderer(), 94, 225, 124, SDL_ALPHA_OPAQUE);
		}
		SDL_RenderFillRect(TheGame::Instance().getRenderer(), &fillRect);
	}
}

void PlayStatePower::loadText()
{
	// Prologue text
	string prologue1 = "Find new components to repair the machine.";
	string prologue2 = "Press <space> to use your jetpack. You need power to use it.";
	string prologue3 = "If you get hurt, you need power to get fixed.";
	string prologue35 = "Press <shift> to run.";
	string prologue4 = "Think before you jump.";
	TheTextureManager::Instance().renderText(prologue1, TheGame::Instance().getHUDFont(), "prologue1");
	TheTextureManager::Instance().renderText(prologue2, TheGame::Instance().getHUDFont(), "prologue2");
	TheTextureManager::Instance().renderText(prologue3, TheGame::Instance().getHUDFont(), "prologue3");
	TheTextureManager::Instance().renderText(prologue4, TheGame::Instance().getHUDFont(), "prologue4");
	TheTextureManager::Instance().renderText(prologue35, TheGame::Instance().getHUDFont(), "prologue35");
	// Epilogue
	string epilogue1 = "You have repaired the machine";
	string epilogue2 = "You need a minimun amount of power to turn it on.";
	string epilogue3 = "You also need power to make it work.";
	string epilogue4 = "If you want to try it get close to it. Otherwise, go left.";
	TheTextureManager::Instance().renderText(epilogue1, TheGame::Instance().getHUDFont(), "epilogue1");
	TheTextureManager::Instance().renderText(epilogue2, TheGame::Instance().getHUDFont(), "epilogue2");
	TheTextureManager::Instance().renderText(epilogue3, TheGame::Instance().getHUDFont(), "epilogue3");
	TheTextureManager::Instance().renderText(epilogue4, TheGame::Instance().getHUDFont(), "epilogue4");

}

void PlayStatePower::drawImages()
{
	auto levelIndex = TheGame::Instance().getCurrentLevel();
	string levelName = TheGame::Instance().getLevelFiles()[levelIndex].first;
	if (levelName == "prologue")		
	{
		TheTextureManager::Instance().draw("machineRobot", 181, 333, TheGame::Instance().getRenderer());
	}
	else if (levelName == "level2")
	{
		TheTextureManager::Instance().draw("progress1", 540, 0, TheGame::Instance().getRenderer());
	}
	else if (levelName == "level3")
	{
		TheTextureManager::Instance().draw("progress2", 510, 0, TheGame::Instance().getRenderer());
	}
	else if (levelName == "level4")
	{
		TheTextureManager::Instance().draw("progress3", 480, 0, TheGame::Instance().getRenderer());
	}
}
