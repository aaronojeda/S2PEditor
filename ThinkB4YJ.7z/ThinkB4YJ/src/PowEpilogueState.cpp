#include "PowEpilogueState.h"
#include "Game.h"
#include "TextureManager.h"
#include "SoundManager.h"
#include "InputHandler.h"
#include "PauseState.h"
#include "EndState.h"
#include "PowDecisionState.h"

PowEpilogueState::PowEpilogueState()
{
	loadLevel("levels/epilogue.xml");
	SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
}

PowEpilogueState::~PowEpilogueState()
{
}

void PowEpilogueState::update()
{
	if (TheGame::Instance().resurrected())
	{
		// Reload level and reset player resurrected flag
		loadLevel("levels/epilogue.xml");
		TheGame::Instance().setResurrected(false);
		// Reset keys to zero
		TheGame::Instance().clearKeys();
	}
	// Check if player reachs the machine
	if (m_pLevel->getPlayer()->getPosition().x() > 222 && !m_bFadeout)
	{
		m_bFadeout = true;
		m_initialTime = SDL_GetTicks();
	}
	else
	{
		// Handle input and update level
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_ESCAPE))
		{
			TheGame::Instance().quit();
		}
		if (!TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN))
		{
			m_bPausePressed = false;
		}
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN) && !m_bPausePressed)
		{
			m_bPausePressed = true;
			TheGame::Instance().getStateMachine()->pushState(new PauseState());
		}
		else
		{
			m_pLevel->update();
		}
	}
}

void PowEpilogueState::render()
{
	drawPower();
	drawImages();
	// Draw level objects and terrain
	if (m_pLevel != 0)
	{
		m_pLevel->render();
	}
	if (m_bFadeout)	fadeout();
}


void PowEpilogueState::drawImages()
{
	TheTextureManager::Instance().draw("machineRobot", 181, 333, TheGame::Instance().getRenderer());
	TheTextureManager::Instance().draw("progress4", 450, 0, TheGame::Instance().getRenderer());
}

void PowEpilogueState::fadeout()
{
	if (m_alphaEnding < 255)
	{
		// player goes left
		// fade out to black
		Uint32 fadeTime = 1000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding++;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
		TheGame::Instance().getStateMachine()->changeState(new PowDecisionState());
		TheGame::Instance().getStateMachine()->dequeState();
	}
}