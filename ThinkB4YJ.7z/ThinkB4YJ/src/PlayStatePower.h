#pragma once
#include "PlayState.h"
class PlayStatePower :
	public PlayState
{
public:
	PlayStatePower();
	PlayStatePower(int levelFile);
	PlayStatePower(std::string levelFile);
	virtual ~PlayStatePower();
	virtual void update();
	virtual void render();
protected:
	// level-specific drawing
	void loadText();
	void drawPower();
	virtual void drawImages();
	void drawText();
	// endings
	void chooseEnding();
	void showBadEnding();
	void showNormalEnding();
	void showGoodEnding();

	int m_alphaEnding{ 0 };
	bool m_bBadEnding{ false };
	bool m_bGoodEnding{ false };
	bool m_bNormalEnding{ false };
	Uint32 m_initialTime{ 0 };
	void drawEndings();
};

