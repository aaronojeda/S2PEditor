#include "GoodEndingState.h"
#include "LeftRight.h"
#include "LoaderParams.h"
#include "Collision.h"
#include "Game.h"
#include "SoundManager.h"
#include "TextureManager.h"
#include "ObjectLayer.h"
#include "happyRobot.h"
#include "EndState.h"

using namespace std;

GoodEndingState::GoodEndingState()
{
	loadLevel("levels/goodEnding.xml");
	m_alphaEnding = 255;
	SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
	loadText();
	m_initialTime = SDL_GetTicks();
	m_endingTime = SDL_GetTicks();
}

GoodEndingState::~GoodEndingState()
{
}

void GoodEndingState::update()
{
	m_pLevel->update();
}

void GoodEndingState::render()
{
	drawImages();
	// Draw level objects and terrain
	if (m_pLevel != 0)
	{
		m_pLevel->render();
	}
	if (!m_bFadeInFinished)	fadeIn();
	if (SDL_GetTicks() - m_endingTime > 5000)
	{
		if (!m_bFlag)
		{
			m_initialTime = SDL_GetTicks();
			m_bFlag = true;
		}
		fadeOut();
	}
}

void GoodEndingState::drawImages()
{
	TheTextureManager::Instance().draw("machineOnEmpty", 209, 326, TheGame::Instance().getRenderer());
	// Dibujar energia del robot amigo
	TheTextureManager::Instance().draw("batteryEmpty", 539, 10, TheGame::Instance().getRenderer(), SDL_FLIP_HORIZONTAL);
	TheTextureManager::Instance().draw("batteryEmpty", 10, 10, TheGame::Instance().getRenderer());
	// robot1 health
	int rectWidth = 42;
	int rectHeight = 18;
	int fillWidth = rectWidth * 40/ 100;
	SDL_SetRenderDrawColor(TheGame::Instance().getRenderer(), 232, 15, 56, SDL_ALPHA_OPAQUE);
	SDL_Rect fillRect = { 13, 13, fillWidth, rectHeight };
	SDL_RenderFillRect(TheGame::Instance().getRenderer(), &fillRect);
	// robot2 health
	fillRect = { 590 - fillWidth - 3, 13, fillWidth, rectHeight };
	SDL_RenderFillRect(TheGame::Instance().getRenderer(), &fillRect);
}

void GoodEndingState::fadeIn()
{
	if (m_alphaEnding > 0)
	{
		// player goes left
		// fade out to black
		Uint32 fadeTime = 1000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding--;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		m_bFadeInFinished = true;
	}
}

void GoodEndingState::fadeOut()
{
	if (m_alphaEnding < 255)
	{
		// fade out to black
		Uint32 fadeTime = 4000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding++;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
		TheGame::Instance().getStateMachine()->changeState(new EndState());
		TheGame::Instance().getStateMachine()->dequeState();
	}
}