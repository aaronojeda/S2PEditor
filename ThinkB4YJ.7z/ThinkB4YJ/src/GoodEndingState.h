#pragma once
#include "PlayStatePower.h"
class GoodEndingState :
	public PlayStatePower
{
public:
	GoodEndingState();
	~GoodEndingState();
	virtual void update();
	virtual void render();
	virtual std::string getStateID() const { return "GoodEndingState"; }
private:
	bool m_bFadeInFinished{ false };
	bool m_bFlag{ false };
	void fadeIn();
	void fadeOut();
	void drawImages();
	Uint32 m_endingTime;
};