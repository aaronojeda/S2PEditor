#include "PowDecisionState.h"
#include "TextureManager.h"
#include "Game.h"
#include "InputHandler.h"
#include "PauseState.h"
#include "EndState.h"
#include "PlayerPower.h"
#include "PowNormalEndState.h"
#include "GoodEndingState.h"
#include "SoundManager.h"

using namespace std;

PowDecisionState::PowDecisionState()
{
	loadLevel("levels/decision.xml");
	m_player = m_pLevel->getPlayer();
	SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
	loadText();
}

PowDecisionState::~PowDecisionState()
{
}

void PowDecisionState::update()
{
	if (m_bBadEnding || m_bNormalEnding)
	{
		// shut down robot
		dynamic_cast<PlayerPower*>(m_player)->shutDown(m_switchTime);
	}
	else if (m_bLeaving)
	{
		// no activa la palanca, se va
		dynamic_cast<PlayerPower*>(m_player)->goLeft();
	}
	else
	{
		if (TheGame::Instance().resurrected())
		{
			// Reload level and reset player resurrected flag
			loadLevel(m_levelFile);
			TheGame::Instance().setResurrected(false);
			// Reset keys to zero
			TheGame::Instance().clearKeys();
		}
		// Check if player leaves
		if (m_pLevel->getPlayer()->getPosition().x() < 0)
		{
			m_bLeaving = true;
			m_initialTime = SDL_GetTicks();
		}
		// check if player turns machine on
		else if (m_player->getPosition().x() > 200)
		{
			m_switchTime = SDL_GetTicks();
			// different options
			auto power = TheGame::Instance().getHealth();
			if (power < 50)
			{
				m_bBadEnding = true;
				int health = TheGame::Instance().getHealth();
				TheGame::Instance().addHealth(-(health-1));
				// play death sound
				TheSoundManager::Instance().playSound("shutdownSnd", 0);
			}
			else if (power < 75)
			{
				m_bNormalEnding = true;
				// play death sound
				TheSoundManager::Instance().playSound("shutdownSnd", 0);
			}
			else m_bGoodEnding = true;
		}
		else
		{
			// Handle input and update level
			if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_ESCAPE))
			{
				TheGame::Instance().quit();
			}
			if (!TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN))
			{
				m_bPausePressed = false;
			}
			if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RETURN) && !m_bPausePressed)
			{
				m_bPausePressed = true;
				TheGame::Instance().getStateMachine()->pushState(new PauseState());
			}
			else
			{
				m_pLevel->update();
			}
		}
	}
}

void PowDecisionState::render()
{
	drawText();
	drawImages();
	drawPower();
	// Draw level objects and terrain
	if (m_pLevel != 0)
	{
		m_pLevel->render();
	}
	drawPower();
	if (m_bLeaving || m_bBadEnding || m_bNormalEnding || m_bGoodEnding)
	{
		fadeout();
	}
}


void PowDecisionState::drawImages()
{
	if (m_bBadEnding)
	{
		TheTextureManager::Instance().draw("machineOff", 209, 326, TheGame::Instance().getRenderer());
	}
	else if (m_bNormalEnding || m_bGoodEnding)
	{
		TheTextureManager::Instance().draw("machineOnFull", 209, 326, TheGame::Instance().getRenderer());
	}
	else
	{
		TheTextureManager::Instance().draw("machineFixedRobot", 209, 326, TheGame::Instance().getRenderer());
	}
	// Dibujar energia del robot amigo
	TheTextureManager::Instance().draw("batteryEmpty", 539, 10, TheGame::Instance().getRenderer(), SDL_FLIP_HORIZONTAL);
}

void PowDecisionState::fadeout()
{
	if (m_alphaEnding < 255)
	{
		// fade out to black
		Uint32 fadeTime = 1000;
		int incTime = fadeTime / 255;
		if (SDL_GetTicks() - m_initialTime > incTime)
		{
			m_alphaEnding++;
			SDL_SetTextureAlphaMod(TheTextureManager::Instance().getTextureMap()["blackScreen"], m_alphaEnding);
			m_initialTime = SDL_GetTicks();
		}
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
	}
	else
	{
		TheTextureManager::Instance().draw("blackScreen", 0, 0, TheGame::Instance().getRenderer());
		if (m_bNormalEnding)
		{
			TheGame::Instance().getStateMachine()->changeState(new PowNormalEndState());
		}
		else if (m_bGoodEnding)
		{
			TheGame::Instance().getStateMachine()->changeState(new GoodEndingState());
		}
		else
		{
			TheGame::Instance().getStateMachine()->changeState(new EndState());
		}
		TheGame::Instance().getStateMachine()->dequeState();
	}
}

void PowDecisionState::loadText()
{
	string decision1 = "You have repaired the machine";
	string decision2 = "You need a minimun amount of power to turn it on.";
	string decision3 = "You also need power to make it work.";
	string decision4 = "If you want to try it get close to it. Otherwise, go left.";
	TheTextureManager::Instance().renderText(decision1, TheGame::Instance().getHUDFont(), "decision1");
	TheTextureManager::Instance().renderText(decision2, TheGame::Instance().getHUDFont(), "decision2");
	TheTextureManager::Instance().renderText(decision3, TheGame::Instance().getHUDFont(), "decision3");
	TheTextureManager::Instance().renderText(decision4, TheGame::Instance().getHUDFont(), "decision4");
}

void PowDecisionState::drawText()
{
	TheTextureManager::Instance().draw("decision1", 10, 75, TheGame::Instance().getRenderer());
	TheTextureManager::Instance().draw("decision2", 10, 115, TheGame::Instance().getRenderer());
	TheTextureManager::Instance().draw("decision3", 10, 155, TheGame::Instance().getRenderer());
	TheTextureManager::Instance().draw("decision4", 10, 195, TheGame::Instance().getRenderer());
}