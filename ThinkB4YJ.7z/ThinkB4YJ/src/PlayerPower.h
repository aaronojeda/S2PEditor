#pragma once
#include "Player.h"
class PlayerPower :
	public Player
{
public:
	PlayerPower();
	~PlayerPower();
	virtual void update();
	virtual void load(std::unique_ptr<LoaderParams> const &pParams);
	void setXvel(int vel) { m_xSpeed = vel; }
	void goLeft();
	void goRight();
	void shutDown(int startTime);
private:
	int m_jumpCost{ 20 };

	virtual void handleInput();
	virtual void PlayerPower::handleAnimation();
	void jumpConsumed();
};

class PlayerPowerCreator : public BaseCreator
{
	GameObject* createGameObject() const
	{
		return new PlayerPower();
	}
};


