#include "PlayerPower.h"
#include "InputHandler.h"
#include "SoundManager.h"
#include "Game.h"
#include <algorithm>

using namespace std;

PlayerPower::PlayerPower()
{
}


PlayerPower::~PlayerPower()
{
}

void PlayerPower::load(unique_ptr<LoaderParams> const &pParams)
{
	Player::load(pParams);
	SDL_Rect fallingFrame{ 192, 0, 48, 48 };
	vector<SDL_Rect> fallingFrames;
	fallingFrames.push_back(fallingFrame);
	Animation fallingAnim{ m_animations["idle"].getTextureID(), 4, fallingFrames, 0, m_animations["idle"].getCollider() };
	m_animations.insert(pair<string, Animation>("falling", fallingAnim));
}

void PlayerPower::handleInput()
{
	if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_LEFT))
	{
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RIGHT))
		{
			m_bMoveRight = false;
			m_bMoveLeft = false;
		}
		else
		{
			if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_LSHIFT))
			{
				m_bRunning = true;
			}
			else
			{
				m_bRunning = false;
			}

			m_bMoveRight = false;
			m_bMoveLeft = true;
		}
	}
	else if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_RIGHT))
	{
		if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_LSHIFT))
		{
			m_bRunning = true;
		}
		else
		{
			m_bRunning = false;
		}

		m_bMoveRight = true;
		m_bMoveLeft = false;
	}
	else
	{
		m_bMoveLeft = false;
		m_bMoveRight = false;
	}

	if (TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_SPACE) && m_bCanJump && !m_bPressedJump)
	{
		// Actions just before jumping
		TheSoundManager::Instance().playSound(m_sndJmp, 0);
		m_bJumping = true;
		m_bCanJump = false;
		m_beforeJumpY = m_position.y();
		m_bPressedJump = true;
		// correct power
		jumpConsumed();
	}
	if (!TheInputHandler::Instance().isKeyDown(SDL_SCANCODE_SPACE) && m_bCanJump)
	{
		// Jump key has been released and player can jump in that position
		m_bPressedJump = false;
	}
}


void PlayerPower::update()
{
	if (!m_bDying)
	{
		// get the player input
		handleInput();

		if (m_bMoveLeft)
		{
			if (m_bRunning)
			{
				m_velocity.x(-(m_xSpeed * 2));
			}
			else
			{
				m_velocity.x(-m_xSpeed);
			}
		}
		else if (m_bMoveRight)
		{
			if (m_bRunning)
			{
				m_velocity.x(m_xSpeed * 2);
			}
			else
			{
				m_velocity.x(m_xSpeed);
			}
		}
		else // not moving
		{
			m_velocity.x(0);
		}

		if (!m_bJumping)
		{
			m_velocity.y(m_jumpSpeed);
		}
		else
		{
			// if we are higher than the jump height set jumping to false
			if (m_position.y() < m_beforeJumpY - m_jumpHeight)
			{
				m_bJumping = false;
			}

			m_velocity.y(-m_jumpSpeed);
		}

		handleMovement(m_velocity);
	}
	else   // Dying
	{
		m_velocity.x(0);
		// sumamos tiempo a m_dyingAnimTime para prolongar el ultimo frame con el robot apagado
		if ((SDL_GetTicks() - m_deathTime) > m_dyingAnimTime + 1000)
		{
			// Death animation finished. Resurrect the player
			resurrect();
		}
	}

	handleAnimation();
}

void PlayerPower::handleAnimation()
{
	// if the player is invulnerable we can flash its alpha to let people know
	if (m_bInvulnerable)
	{
		// invulnerability is finished, set values back
		if (m_invulnerableCounter == m_invulnerableTime)
		{
			m_bInvulnerable = false;
			m_invulnerableCounter = 0;
			m_alpha = 255;
		}
		else // otherwise, flash the alpha on and off
		{
			if (m_alpha == 255)
			{
				m_alpha = 0;
			}
			else
			{
				m_alpha = 255;
			}
		}

		// increment our counter
		m_invulnerableCounter++;
	}

	if (!m_bDying)
	{
		// Check orientation and flip sprite if necessary
		if (m_velocity.x() < 0)
		{
			// Going left
			m_sdlFlip = SDL_FLIP_HORIZONTAL;
		}
		else if (m_velocity.x() > 0)
		{
			// Going right
			m_sdlFlip = SDL_FLIP_NONE;
		}
		// Check if jumping or falling
		if (m_velocity.y() != 0)
		{
			if (m_velocity.y() > 0)
			{
				// falling
				m_currentAnim = m_animations["falling"];
			}
			else
			{
				// Jumping
				m_currentAnim = m_animations["jump"];
			}
		}
		else
		{
			// Not jumping nor falling
			if (m_velocity.x() == 0)
			{
				// Stopped
				m_currentAnim = m_animations["idle"];
				m_currentAnim.setFrame(int(SDL_GetTicks() / (m_currentAnim.getFrameTime() * 2)) % m_currentAnim.getNFrames());
			}
			else
			{
				// Moving left or right
				m_currentAnim = m_animations["walk"];
				// Check if running
				if (m_bRunning)
				{
					m_currentAnim.setFrame(int(SDL_GetTicks() / m_currentAnim.getFrameTime()) % m_currentAnim.getNFrames());
				}
				else
				{
					m_currentAnim.setFrame(int(SDL_GetTicks() / (m_currentAnim.getFrameTime() * 2)) % m_currentAnim.getNFrames());
				}
			}
		}
	}
	else   // Dying
	{
		// para prolongar el ultimo frame
		if (m_currentAnim.getFrameIndex() != m_currentAnim.getNFrames() - 1)
		{
			m_currentAnim.setFrame(int((SDL_GetTicks() - m_deathTime) / m_currentAnim.getFrameTime()) % m_currentAnim.getNFrames());
		}
	}
}


void PlayerPower::jumpConsumed()
{

	// Player has been hurt
	int prevLives = TheGame::Instance().getLives();
	TheGame::Instance().addHealth(-m_jumpCost);
	// addHealth can make player lose a life
	if (TheGame::Instance().getLives() < prevLives)
	{
		// Player has dead
		m_currentAnim = m_animations["death"];
		m_deathTime = SDL_GetTicks();
		m_bDying = true;
		m_bJumping = false; // to avoid jumping after respawn	
		// play death sound
		TheSoundManager::Instance().playSound(m_sndDeath, 0);
	}
}

void PlayerPower::goLeft()
{
	m_velocity.x(-2);
	m_position.x(m_position.x() - 2);
	handleAnimation();
}

void PlayerPower::goRight()
{
	m_velocity.x(2);
	m_position.x(m_position.x() + 2);
	handleAnimation();
}

void PlayerPower::shutDown(int startTime)
{
	m_currentAnim = m_animations["death"];
	auto time = SDL_GetTicks() - startTime;
	if (time < 500)
	{
		m_currentAnim.setFrame(0);
	}
	else if (time < 1000)
	{
		m_currentAnim.setFrame(1);
	}
	else if (time < 1500)
	{
		m_currentAnim.setFrame(2);
	}
	else
	{
		m_currentAnim.setFrame(3);
	}
}