#pragma once
#include "PlayStatePower.h"
class PowDecisionState :
	public PlayStatePower
{
public:
	PowDecisionState();
	~PowDecisionState();
	virtual void update();
	virtual void render();
protected:
	virtual void drawImages();
	bool m_bLeaving{ false };
	Uint32 m_switchTime{ 0 };
	Player* m_player{ nullptr };
	void fadeout();
	void loadText();
	void drawText();
};

