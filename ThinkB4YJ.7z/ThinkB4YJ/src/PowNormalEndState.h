#pragma once
#include "PlayStatePower.h"
class PowNormalEndState :
	public PlayStatePower
{
public:
	PowNormalEndState();
	~PowNormalEndState();
	virtual void update();
	virtual void render();
private:
	void fadeIn();
	void fadeOut();
	Player* m_player{ nullptr };
	bool m_bFadeInFinished{ false };
	void drawImages();
};

